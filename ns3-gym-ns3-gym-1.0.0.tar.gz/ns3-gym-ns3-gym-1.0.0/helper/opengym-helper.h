/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef OPENGYM_HELPER_H
#define OPENGYM_HELPER_H

namespace ns3 {

/* ... */

}

#endif /* OPENGYM_HELPER_H */

